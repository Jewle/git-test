import React, { Component } from 'react';

import './random-planet.css';
import SwapiService from "../../services/swapi.service";
import {Spinner} from "../spinner/spiner";
import {SimpleError} from "../simple-error/simple-error";

export default class RandomPlanet extends Component {
    interval = null
  state = {
    planet:{},
    isLoaded:false,
    hasErrors:false
  }

  swapi = new SwapiService()


  componentDidMount() {
        this.updatePlanet()
      this.interval = setInterval(this.updatePlanet,10000)
  }
  componentWillUnmount() {
      clearInterval(this.interval)
  }

//fix image
updatePlanet = async ()=>{
    try{
        this.setState({isLoaded:false})
        const id = Math.floor(Math.random()*25)+2
        const planet = await this.swapi.getPlanet(id)
        this.setState({planet,isLoaded:true})
    }
    catch (e) {
        this.setState({hasErrors:true, isLoaded:true})
    }
  }
  render() {
    const {isLoaded, planet , hasErrors} = this.state
    const content = isLoaded? <PlanetView planet={planet}/> : <Spinner/>

    return (
      <div className="random-planet jumbotron rounded">
          {hasErrors ? <SimpleError/> : content}
      </div>

    );
  }
}


const PlanetView = ({planet})=>{
    const {diameter,population,rotationPeriod,name,id} = planet
    return (
        <React.Fragment>
            <img className="planet-image"
                 src={`https://starwars-visualguide.com/assets/img/planets/${id||'2'}.jpg`} />
            <div>
                <h4>{name}</h4>
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">
                        <span className="term">Population</span>
                        <span>{population}</span>
                    </li>
                    <li className="list-group-item">
                        <span className="term">Rotation Period</span>
                        <span>{rotationPeriod}</span>
                    </li>
                    <li className="list-group-item">
                        <span className="term">Diameter</span>
                        <span>{diameter}</span>
                    </li>
                </ul>
            </div>
        </React.Fragment>
    )
}
