import React from 'react'
import ReactDOM from 'react-dom';

export const SimpleError = () =>{
    return (
        <div className="alert alert-danger" role="alert">
            Something went wrong
        </div>
    )
}
