import React, { Component } from 'react';

import './item-details.css';


const Record = ({item,field,label}) => {
    return (
        <li className="list-group-item">
            <span className="term">{label}</span>
            <span>{item[field]}</span>
        </li>
    )
}
export {
    Record
}

export default class ItemDetails extends Component {

    state = {
        item:{},
        isLoaded:false
    }
    async fetchItem(id){

        const item = await this.props.getData(id)
        this.setState({item})
    }

    componentDidMount() {
        console.log('mounted')
        this.fetchItem(5)
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.personId!== this.props.personId){
            const itemId  = this.props.personId || 3
            this.fetchItem(itemId)
        }
    }


    render() {
        const {item} = this.state
        const {getImage} = this.props


        return (

            <div className="person-details card">
                <img className="person-image"
                     src={getImage(item.id)} />

                <div className="card-body">
                    <h4>{item.name}</h4>
                    <ul className="list-group list-group-flush">
                        {/*Клонируем jsx элементы, добавляя свойство item*/}
                        {React.Children.map(this.props.children, (child, index)=>{
                            child = React.cloneElement(child, {item})
                            return child
                        })}
                    </ul>
                </div>
            </div>
        )
    }
}
