import React, {Component} from 'react';

import Header from '../header';
import RandomPlanet from '../random-planet';
import ItemList from '../item-list';
import PersonDetails from '../person-details';
import './app.css';
import SwapiService from "../../services/swapi.service";
import Row from "../row/row.component";
import ItemDetails, {Record} from "../item-details/item-details.component";



export class App extends Component{
    swapiService = new SwapiService()
    state = {
        showRandomPlanet:true,
        selectedPerson:1
    }
    onSelectPerson = (id)=>{
        this.setState({
            selectedPerson:id
        })
    }
    planetList =(<ItemList
        getData={this.swapiService.getAllPlanets}
        renderItem={(item)=>item.name + `( ${item.diameter})`} />)

    toggleRandomPlanet = ()=>{
    this.setState(state=>{
        return {...state, showRandomPlanet: !state.showRandomPlanet}
    })
}
  render () {
     const {showRandomPlanet} = this.state
     const  personList =(<ItemList onSelectPerson = {this.onSelectPerson} getData={this.swapiService.getAllPeople}>
                                 {(item)=>item.name}

                        </ItemList>)

     const personDetails =(
         <ItemDetails getData={this.swapiService.getPerson}
                      personId={this.state.selectedPerson}
                      getImage={this.swapiService.getPersonImage}>
             <Record field = "gender" label="Gender"/>
             <Record field="eyeColor" label="Eye color"/>

         </ItemDetails>
          )

      const starshipDetails =(
          <ItemDetails getImage={this.swapiService.getStarShipImage}
                       getData = {this.swapiService.getAllStarShip}>

              <Record field = "model" label="Model"/>
              <Record field="length" label="Length"/>
              <Record field="costInCredits" label="Cost"/>
          </ItemDetails>

          )

      return (
          <div>
              <Header />
              { showRandomPlanet ? <RandomPlanet/> : null}
              <button type="button" onClick={this.toggleRandomPlanet} className="btn btn-warning">Toggle</button>
              <Row left = {starshipDetails} right={personDetails} />
              </div>

      );
  }
};

export default App;


