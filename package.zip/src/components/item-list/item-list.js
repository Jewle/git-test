import React, { Component } from 'react';

import './item-list.css';

import {Spinner} from "../spinner/spiner";
import {SimpleError} from "../simple-error/simple-error";

export default class ItemList extends Component {

    state = {
        people:{},
        isLoaded:false,
        hasErrors:false
    }
    componentDidMount() {
        this.updateItem()
    }

    async updateItem(){
        const {getData} = this.props
        try{
            const people  = await getData()
            this.setState({isLoaded:true , people})

        }
        catch (e) {
            console.log(e)
            this.setState({hasErrors:true})
        }



    }

    listView = (people)=>{
        return (
            <ul className="item-list list-group">
                {people.map(i=>{
                    const label = this.props.children(i)
                     return (<li key={i.id}
                        className="list-group-item"
                        onClick={()=>this.props.onSelectPerson(i.id)}>
                        {label}
                    </li>)}
                )}
            </ul>
        )
    }

    onToggleItem = (id)=>{

    }

    render() {
        const {isLoaded, people , hasErrors} = this.state
        const content = isLoaded? this.listView(people) : <Spinner/>

        return hasErrors ? <SimpleError/> : content

  }
}


