import React from 'react'
import ReactDOM from 'react-dom';
import './spinner.css'

export  const Spinner = ()=>{
    return (
      <div className='container'>
          <div className = "loadingio-spinner-ellipsis-i2s4ewp7zss" >
              <div className = "ldio-nz4qbhncnrh">
                  <div></div><div></div>
                  <div></div><div></div><div></div>
              </div>
          </div>
      </div>
    )
}
