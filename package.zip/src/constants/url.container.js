export const SWAPI = 'https://swapi.dev/api'
